library(testthat)
library(robustSingleCell)

test_check("robustSingleCell")
